Video Editor

## Tools

* Video comvert
* Video Merge

## Environments

* Nodejs v10.16.0
* React js 16.8.6

## Steps

* Clone the files and folders
* move to video-editor by cd video-editor
* npm install
* start react server - npm start
* move to server folder 
* start node server  -  node index.js

## URL
* http://localhost:3000



