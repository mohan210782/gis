var express = require('express');
var app = express();
const fileUpload = require('express-fileupload');
var multer = require('multer')
var cors = require('cors');
var fs    = require("fs");
var ffmpeg = require('ffmpeg');
var util = require('util');

const ffmpegPath = require('@ffmpeg-installer/ffmpeg').path;
const ffprobePath = require('@ffprobe-installer/ffprobe').path;

var FFmpeg = require('fluent-ffmpeg');

FFmpeg.setFfmpegPath(ffmpegPath);
FFmpeg.setFfprobePath(ffprobePath);


app.use(cors())

function getMeta(fileUrl,callback){
    //console.log("fileUrl",fileUrl);
    
    FFmpeg(fileUrl)
    .ffprobe(function(err, data) {
        var metadata = util.inspect(data, {showHidden: false, depth: null});
      //callback(metadata);
      callback(data);
    });
}


function availableFormats(){
  FFmpeg.getAvailableFormats(function(err, formats) {
    console.log('Available formats:');
    console.log(formats);
    return formats;
    //callback(formats);
  });
}

function availableEncoders(){
  FFmpeg.getAvailableEncoders(function(err, encoders) {
    console.log('Available encoders:');
    console.log(encoders);
    return encoders;
  });
}

function processVideo(meta,callback){
    console.log("file", meta.fileName);


    //var fps =(meta.fps)? meta.fps : 0; 
    var paddingColour =(meta.paddingColour)? meta.paddingColour : 'white'; 
      try {
        var command = FFmpeg({ 
            source: './uploads/'+meta.fileName,
            preset: './presets',
            timeout: 0,
            priority: 0,
            nolog: false,
            
        })
        .toFormat(meta.format)
        // .noAudio(false)
        .fps(meta.fps)
        .videoBitrate('100k', true)
        // .videoFilters('fade=in:'+fade)
        .size(meta.videoWidth+'x?')
        .aspect(meta.aspect)
        .autopad(paddingColour)
        .seekInput(meta.startTime)
        .duration(meta.duraTime)
        .on('error', function(err) {
            console.log('An error occurred: ' + err.message);
        })
        .on('end', function(req,res) {
            console.log('Processing finished !');
            //res.json({"status":  "Processing finished !"});
            callback('sample.'+meta.format);
          
        })
        .saveToFile('./uploads/converted/sample.'+meta.format,function(err,data){
          //return '../converted/sample.'+meta.format;
          console.log("finished");
          callback(meta.format)
        });
        
    } catch (e) {
        console.log(e.code);
        console.log(e.msg);
    }
}


function mergeVideo(meta,callback){
  console.log("file", meta.fileName1);


  //var fade =(meta.fade)? meta.fade : 0; 
  var paddingColour =(meta.paddingColour)? meta.paddingColour : 'white'; 
    try {
      var command = FFmpeg()
      .input('./uploads/'+meta.fileName1)
      .input('./uploads/'+meta.fileName2)
      .on('error', function(err) {
        console.log('An error occurred: ' + err.message);
      })
      .on('end', function() {
        console.log('Merging finished !');
      })
      .mergeToFile('sample.'+meta.format, '/uploads/mergetemp')
      .saveToFile('./uploads/merged/sample.'+meta.format,function(err,data){
        //return '../converted/sample.'+meta.format;
        console.log("finished");
        callback(meta.format)
      });
      
  } catch (e) {
      console.log(e.code);
      console.log(e.msg);
  }
}



module.exports.getMeta = getMeta;
module.exports.availableFormats = availableFormats;
module.exports.availableEncoders = availableEncoders;
module.exports.processVideo = processVideo;
module.exports.mergeVideo = mergeVideo;