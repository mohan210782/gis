var express = require('express');
var app = express();
const fileUpload = require('express-fileupload');
var multer = require('multer')
var cors = require('cors');
var fs    = require("fs");
var ffmpeg = require('ffmpeg');
var util = require('util');
var bodyParser = require('body-parser')

const ffmpegPath = require('@ffmpeg-installer/ffmpeg').path;
const ffprobePath = require('@ffprobe-installer/ffprobe').path;

var FFmpeg = require('fluent-ffmpeg');

FFmpeg.setFfmpegPath(ffmpegPath);
FFmpeg.setFfprobePath(ffprobePath);


app.use(cors())

// parse application/json
app.use(bodyParser.json())

let videoAction = require('./video/actions');

app.get('/',function(req,res){
    res.json({"test": "yes"});
});

app.use(fileUpload());


//video upload
app.post('/upload', function(req, res) {
  if (Object.keys(req.files).length == 0) {
    return res.status(400).send('No files were uploaded.');
  }

  let sampleFile = req.files.file;

  sampleFile.mv('./uploads/'+req.files.file.name, function(err) {
    if (err)return res.status(500).send(err);
    videoAction.getMeta('./uploads/'+req.files.file.name,function(data){
        //if (err) return console.error(err);
        console.log("metadata------------------------------",data);
        res.json({"status": "File uploaded", "fileName": req.files.file.name, "metadata": data});
    })
    //res.send('File uploaded!');
    
  });
});

//video load for streaming

app.get('/videostreaming',function(req, res){
    console.log(req.query);
    res.json({"status": "video loaded", "fileName": req.query.fileName});
});



  //get video meta deta
  app.get('/videometa', function(req,res){
 
    let fileUrl = './uploads/vid.mp4';
    videoAction.getMeta(fileUrl,function(data){
        if (err) return console.error(err);
        res.json({"test": data});
    })
});

//convert
app.post('/convert', function(req,res){
  console.log("convert-----",req.body);
  videoAction.processVideo(req.body.meta,function(data){
    //if (err) return console.error(err);
    console.log("ttetetetetett",data);
    res.json({"available": data});
  })
});


//merge
app.post('/merge', function(req,res){
  console.log("merge-----",req.body);
  videoAction.mergeVideo(req.body.meta,function(data){
    //if (err) return console.error(err);
    console.log("ttetetetetett",data);
    res.json({"available": data});
  })
});


app.get('/availableformats',function(req,res){
videoAction.availableFormats(function(err,data){
console.log(data);
res.send({"available": data});
})
});

app.get('/availableencoders',function(req,res){
videoAction.availableEncoders(function(err,data){
 console.log(data);
 res.send({"available": data});
})
});




//vide streaming
app.get('/videostartstreaming',function(req, res){
   
    const path = './uploads/'+req.query.fileName;
    const stat = fs.statSync(path)
    const fileSize = stat.size
    const range = req.headers.range
    if (range) {
      const parts = range.replace(/bytes=/, "").split("-")
      const start = parseInt(parts[0], 10)
      const end = parts[1] 
        ? parseInt(parts[1], 10)
        : fileSize-1
      const chunksize = (end-start)+1
      const file = fs.createReadStream(path, {start, end})
      const head = {
        'Content-Range': `bytes ${start}-${end}/${fileSize}`,
        'Accept-Ranges': 'bytes',
        'Content-Length': chunksize,
        'Content-Type': 'video/mp4',
      }
      res.writeHead(206, head);
      file.pipe(res);
    } else {
      const head = {
        'Content-Length': fileSize,
        'Content-Type': 'video/mp4',
      }
      res.writeHead(200, head)
      fs.createReadStream(path).pipe(res)
    }
  });

  //vide streaming
app.get('/downloads',function(req, res){
   
  const path = './uploads/converted/'+req.query.fileName;
  const stat = fs.statSync(path)
  const fileSize = stat.size
  const range = req.headers.range
  if (range) {
    const parts = range.replace(/bytes=/, "").split("-")
    const start = parseInt(parts[0], 10)
    const end = parts[1] 
      ? parseInt(parts[1], 10)
      : fileSize-1
    const chunksize = (end-start)+1
    const file = fs.createReadStream(path, {start, end})
    const head = {
      'Content-Range': `bytes ${start}-${end}/${fileSize}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': chunksize,
      'Content-Type': 'video/mp4',
    }
    res.writeHead(206, head);
    file.pipe(res);
  } else {
    const head = {
      'Content-Length': fileSize,
      'Content-Type': 'video/mp4',
    }
    res.writeHead(200, head)
    fs.createReadStream(path).pipe(res)
  }
});


app.listen(8000, function() {
 preset: './presets',
    console.log('App running on port 8000');

});

