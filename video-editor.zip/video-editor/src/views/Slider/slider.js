import React, { Component, lazy, Suspense, Props } from 'react';
import { Slider, Rail, Handles, Tracks, Ticks } from "react-compound-slider";
import { SliderRail, Handle, Track, Tick , TooltipRail } from "./components"; // example render components - source below

//const domain = [10, 500];
const defaultValues = [0, 0];
const sliderStyle = {
  position: "relative",
  width: "100%",
};

class slider extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          values: defaultValues.slice(),
          update: defaultValues.slice(),
          action: null,
        }
     }

     onUpdate = update => {
      this.setState({ update })
    }
   
    onChange = values => {
      this.setState({ values })
      console.log("values", values);
      this.props.action(values);     
      
    }

   

    
     render() {
      const greeting = 'Welcome to React';
        return (
        
       
          
        <Slider
          mode={2}
          step={1}
          domain={[this.props.domis, this.props.domie]}
          rootStyle={sliderStyle}
          onUpdate={this.onUpdate}
          onChange={this.onChange}
          values={defaultValues}
        >
          <Rail>
            {({ getRailProps }) => <SliderRail getRailProps={getRailProps} />}
           
          </Rail>
          <Handles>
            {({ handles, getHandleProps }) => (
              <div className="slider-handles">
                {handles.map(handle => (
                  <Handle
                    key={handle.id}
                    handle={handle}
                    domain={[this.props.domis, this.props.domie]}
                    getHandleProps={getHandleProps}
                  />
                ))}
              </div>
            )}
          </Handles>
          <Tracks left={false} right={false}>
            {({ tracks, getTrackProps }) => (
              <div className="slider-tracks">
                {tracks.map(({ id, source, target }) => (
                  <Track
                    key={id}
                    source={source}
                    target={target}
                    getTrackProps={getTrackProps}
                  />
                ))}
              </div>
            )}
          </Tracks>
          <Ticks count={5}>
            {({ ticks }) => (
              <div className="slider-ticks">
                {ticks.map(tick => (
                  <Tick key={tick.id} tick={tick} count={ticks.length} />
                ))}
              </div>
            )}
          </Ticks>
        </Slider>
           
        )
     }
}
export default slider;
