import React, { Component, lazy, Suspense } from 'react';
import axios from 'axios';
import ComponentSlider from '../Slider/slider';
import VideoStreaming from './Streaming';
import { AvForm, AvField, AvGroup, AvInput, AvFeedback, AvRadioGroup, AvRadio, } from 'availity-reactstrap-validation';



import {
 
  Card,
  CardBody,
  CardHeader,
  CardFooter,
  Col,
  Row,
  FormGroup,
  Progress,
  Form,
  Button,
  Label,
  Modal, 
  ModalBody, 
  ModalFooter, 
  ModalHeader,
  
} from 'reactstrap';

import Spinner from './Spinner';



class Video extends Component {
  constructor(props) {
    super(props);

    

    this.state = {
      videoLoaded: false,
      dropdownOpen: false,
      radioSelected: 2,
      selectedFile: null,
      domis: 0,
      domie: 0,
      value: 0,
      videosource: null,
      dura : [0,0],
      inputVideoMeta : null,
      modal: false,
      primary: false,
      spinner: false,
      isLoggedIn: false
    };

    // Bind the this context to the handler function
    this.toggle = this.toggle.bind(this);
    this.onRadioBtnClick = this.onRadioBtnClick.bind(this);
    this.handler = this.handler.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.togglePrimary = this.togglePrimary.bind(this);

    
  }  



  // This method will be sent to the child component
  handler = (duraval) => {
    this.setState({dura: duraval});
  }


  componentWillReceiveProps(){
    //console.log("ttettteyyyy",this.props.action);
  }


  componentWillUnmount(){
  
  }


  
  toggle() {
    this.setState({
      dropdownOpen: !this.state.dropdownOpen,
    });
  }
  togglePrimary() {
    this.setState({
      primary: !this.state.primary,
    });
  }

  onRadioBtnClick(radioSelected) {
    this.setState({
      radioSelected: radioSelected,
    });
  }

  onChangeHandler=event=>{  
    console.log(event.target.files[0]);
    this.setState({
      selectedFile: event.target.files[0],
      loaded: 0,
      conveting : 0,
    })
  }



onClickHandler = () => {
  const data = new FormData() 
  data.append('file', this.state.selectedFile)
  this.setState({ videosource: "http://localhost:8000/videostartstreaming?fileName="+this.state.selectedFile.name,}); 
  

  axios.post("http://localhost:8000/upload", data, { // receive two parameter endpoint url ,form data 

        onUploadProgress: ProgressEvent => {
         
          this.setState({
            loaded: (ProgressEvent.loaded / ProgressEvent.total*100),
          })
        },
      })
      .then(res => { // then print response status
        //console.log("filemeta",res.data.metadata);
        var videoMeta = res.data.metadata;
        this.setState({ domie: res.data.metadata.streams[0].duration,}); 
        var fpsT = videoMeta.streams[0].avg_frame_rate;
        var fpsTT = fpsT.split('/');
        //console.log("fpts",fpsTT[0]);
        var inputVideoMeta = {
          "format" : videoMeta.format.format_name,
          "videoWidth" : videoMeta.streams[0].coded_width,
          "videoHeight" : videoMeta.streams[0].coded_height,
          "aspect" : videoMeta.streams[0].sample_aspect_ratio,
          "duration" : videoMeta.streams[0].duration,
          "bit_rate" : videoMeta.streams[0].bit_rate,
          "frame_rate": fpsTT[0],
        }
        this.setState({
          inputVideoMeta : inputVideoMeta,
          dura : [0,videoMeta.streams[0].duration],
          videoLoaded : true,
         
          }
          
        );
       
        
      })
}



 //form submit
 handleSubmit(event, errors, values) {

  if(this.state.videoLoaded){
    

  
      this.setState({errors, values, spinner: true,  });
      console.log("durarr", this.state.inputVideoMeta.aspect);
      var asp = this.state.inputVideoMeta.aspect;
      var wit = this.state.inputVideoMeta.videoWidth;
      var heig = this.state.inputVideoMeta.videoHeight;
      var bit_rate = this.state.inputVideoMeta.bit_rate;
      var frame_rate = this.state.inputVideoMeta.frame_rate;
      //console.log("value test",errors.length);
      if(errors.length == 0){
        var valueTemp = values;
        Object.keys(values).forEach(function(key) {
          console.log(values[key]);
          if(key == "videoWidth"){
            valueTemp.videoWidth =((values[key] != "") && (values[key] != wit)) ? values[key] : wit;
          }
          if(key == "videoHeight"){
            valueTemp.videoHeight =((values[key] != "") && (values[key] != heig)) ? values[key] : heig;
          }
          if(key == "aspect"){
            valueTemp.aspect =((values[key] != "") && (values[key] != asp)) ? values[key] : asp;
          }
          if(key == "bit_rate"){
            valueTemp.bit_rate =((values[key] != "") && (values[key] != bit_rate)) ? values[key] : bit_rate;
          }
          if(key == "fps"){
            valueTemp.fps =((values[key] != "") && (values[key] != frame_rate)) ? values[key] : frame_rate;
          }
        
        
        });
        valueTemp.startTime = this.state.dura[0];
        valueTemp.duraTime = this.state.dura[1];
        valueTemp.fileName = this.state.selectedFile.name;

        
        //console.log("valueTemp", valueTemp);
        const vidData = new FormData() 
      
        vidData.append('meta', valueTemp);

        //console.log("durarr", this.state.inputVideoMeta.duration);
      
        axios.post("http://localhost:8000/convert", {"meta":valueTemp}, { // receive two parameter endpoint url ,form data 
            onUploadProgress: ProgressEvent => {
            
              this.setState({
                converting: (ProgressEvent.loaded / ProgressEvent.total*100),
              })
            },
          })
          .then(res => { // then print response status
            
            //console.log("res", res);
            this.setState({spinner : false, isLoggedIn : true, outPutFileURL : "http://localhost:8000/downloads?fileName=sample."+valueTemp.format});
            this.togglePrimary()
           
            
            //console.log("res.data.metadata",inputVideoMeta);
          })

      }
    }
    function Greeting(props) {
      const isLoggedIn = props.isLoggedIn;
      if (isLoggedIn) {
        return <h1>Welcome back!</h1>;
      }
     
    }

    

}



  loading = () => <div className="animated fadeIn pt-1 text-center">Loading...</div>

  render() {

    return (
      <div className="animated fadeIn">
       
      <Row>
        <Col>
         
          <Row>
            <Col>
              <Card>
                <CardBody>
                  <VideoStreaming  videosource={this.state.videosource}/>
                  <div  id="slider" style={{  width: "100%" }}>
                      <ComponentSlider domis={0} domie={this.state.domie} onChangeValue={this.handleChangeValue}   action={this.handler} />
                  </div>
                </CardBody>
              </Card>
            </Col>
          </Row>
          <Row>
            <Col>
              <Card>
                <CardBody>
                  <Form action="" method="post" encType="multipart/form-data" className="form-horizontal">
                    <FormGroup row  >
                      <Col xs="12" md="9" className="">
                        <input type="file" name="fileToUpload" accept="video/mp4, video/avi, video/x-flv" className="form-control" id="fileToUpload" onChange={this.onChangeHandler}/>
                        <Progress max="100" color="success" value={this.state.loaded} >{Math.round(this.state.loaded,2) }%</Progress>
                      </Col>
                     </FormGroup>
                  </Form>
                </CardBody>
                <CardFooter>
                  <Button type="submit" size="sm" color="primary" onClick={this.onClickHandler}><i className="fa fa-dot-circle-o"></i> Upload</Button>
                </CardFooter>
              </Card>
            </Col>
          </Row>
        </Col>
        <Col>
          <Row>
            <Col>
            <AvForm onValidSubmit={this.handleValidSubmit} onInvalidSubmit={this.handleInvalidSubmit}  onSubmit={this.handleSubmit} >
              <Card>
                  <CardHeader>
                    <strong>Video</strong> Edit
                  </CardHeader>
                  <CardBody>
                    <Row>
                     
                        <Col>
                          <AvField type="select" name="format" label="Output Format" helpMessage="Output File Format!" required> 
                              <option value="" >Select</option>
                              <option value="mp4" >MP4</option>
                              <option value="avi">AVI</option>
                              <option value="flv">FLV</option>
                          </AvField>
                        </Col>
                        <Col>
                          <AvField type="select" name="fps" label="Output Framerate" helpMessage="Framerate!" > 
                              <option value="" >Select</option>
                              <option value="10" >10</option>
                              <option value="20">20</option>
                              <option value="30">30</option>
                              <option value="40">40</option>
                              <option value="50" >50</option>
                              <option value="60">60</option>
                              <option value="70">70</option>
                              <option value="80">80</option>
                          </AvField>
                        </Col>
                        <Col>
                          <AvField type="select" name="aspect" label="Aspect" helpMessage="Chnage aspect ratio!" > 
                              <option value="" >Select</option>
                              <option value="1" >1</option>
                              <option value="2">2</option>
                              <option value="3">3</option>
                              <option value="4">4</option>
                              <option value="5">5</option>
                          </AvField>
                        </Col>
                     
                    </Row>
                    
                    <Row>
                    
                     <Col>
                        <AvRadioGroup name="paddingColour" label="Padding Colour!" required>
                          <AvRadio customInput label="Red" value="red" />
                          <AvRadio customInput label="Blue" value="blue" />
                          <AvRadio customInput label="Green" value="green" />
                        </AvRadioGroup>
                     </Col>
                     <Col>
                        <AvGroup>
                          <Label for="videoWidth">Width</Label>
                          <AvInput name="videoWidth" id="videoWidth" />
                          <AvFeedback>Video Width!</AvFeedback>
                        </AvGroup>
                     </Col>
                     <Col>
                     <AvField type="select" name="bit_rate" label="BirRate" helpMessage="Chnage BitRate ratio!" > 
                              <option value="" >Select</option>
                              <option value="350" >350kbps</option>
                              <option value="700">700kbps</option>
                              <option value="1200">1200kbps</option>
                              <option value="2500">2500kbps</option>
                              <option value="5000">5000kbps</option>
                          </AvField>
                     </Col>
                  
                 </Row>
                      
                     
              
                    </CardBody>
                    <CardFooter>
                        <Button type="submit" size="sm" color="success"><i className="fa fa-dot-circle-o"></i> Start</Button>
                    </CardFooter>
                </Card>
                <Spinner loading={this.state.spinner}/>
                {/* <Link to="./uploads/convert/sample1.mp4" target="_blank" download>Download</Link> */}

               
               
              </AvForm>
            </Col>
          </Row>
        
        </Col>
      </Row>
      
     
      <Modal isOpen={this.state.primary} toggle={this.togglePrimary}
              className={'modal-primary ' + this.props.className}>
        <ModalHeader toggle={this.togglePrimary}>Modal title</ModalHeader>
        <ModalBody>
          Convertion Process Completed please here to download the file
          <a href={this.state.outPutFileURL} download> Download File >></a>
         
        </ModalBody>
        <ModalFooter>
        
          
        </ModalFooter>
      </Modal>

        
        
       

        
      </div>
    );
  }
}

export default Video;
