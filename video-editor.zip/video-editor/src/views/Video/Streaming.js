import React, { Component, lazy, Suspense } from 'react';
import { Player, BigPlayButton, LoadingSpinner, ControlBar, PlayToggle, ReplayControl} from 'video-react';


const sources = {
    sintelTrailer: 'http://localhost:8000/video',
    bunnyTrailer: 'http://localhost:8000/videostartstreaming?fileName=vid.mp4',
    bunnyMovie: 'http://localhost:8000/videostartstreaming?fileName=vid.mkv',
    test: 'http://localhost:8000/video'
  };
class Streaming extends Component {
    constructor(props,videosource) {
        super(props, videosource);
    
    
    
       
    
        this.state = {
          source: sources['bunnyMovie']
        };
    
        this.play = this.play.bind(this);
        this.pause = this.pause.bind(this);
        this.load = this.load.bind(this);
        this.changeCurrentTime = this.changeCurrentTime.bind(this);
        this.seek = this.seek.bind(this);
        this.changePlaybackRateRate = this.changePlaybackRateRate.bind(this);
        this.changeVolume = this.changeVolume.bind(this);
        this.setMuted = this.setMuted.bind(this);
    
        
      }

      componentWillReceiveProps({videosource}){
        this.setState({ source: this.props.videosource }, () => {
                  console.log(this.state.source, 'dealersOverallTotal14444');
                  this.player.load();
                }); 
    }
      //video actions
        componentDidMount() {
            // subscribe state change
            this.player.subscribeToStateChange(this.handleStateChange.bind(this));
        }

        
        
      setMuted(muted) {
        return () => {
          this.player.muted = muted;
        };
      }

      
      handleStateChange(state) {
        // copy player state to this component's state
        this.setState({
          player: state
        });
      }
      
      play() {
        this.player.play();
      }
      
      pause() {
        this.player.pause();
      }
      
      load() {
        this.player.load();
      }
      
      changeCurrentTime(seconds) {
        return () => {
          const { player } = this.player.getState();
          this.player.seek(player.currentTime + seconds);
        };
      }
      
      seek(seconds) {
        return () => {
          this.player.seek(seconds);
        };
      }
      
      changePlaybackRateRate(steps) {
        return () => {
          const { player } = this.player.getState();
          this.player.playbackRate = player.playbackRate + steps;
        };
      }
      
      changeVolume(steps) {
        return () => {
          const { player } = this.player.getState();
          this.player.volume = player.volume + steps;
        };
      }
      
     
      changeVideoSource(url){
        console.log("video url", url);
        return() =>{
          // this.setState({
          //   source: 'http://localhost:8000/videostartstreaming?fileName=vid.mp4'
          // });
          this.player.load();
        };
      }


     
    
      loading = () => <div className="animated fadeIn pt-1 text-center">Loading...</div>
      playVideo() {
        this.refs.vidRef.play();
      }

      
      render(){
          return(

            <Player ref={player => { this.player = player; }}  >
                <source src={this.state.source} />
                <BigPlayButton position="center" />
                <LoadingSpinner />
                <ControlBar autoHide={false} disableDefaultControls={false}>
                    <PlayToggle />
                    {/* <ReplayControl seconds={5} order={2.1} />
                    <ReplayControl seconds={10} order={2.2} />
                    <ReplayControl seconds={30} order={2.3} /> */}
                </ControlBar>
            </Player>
            
          )
      }
    
}

export default Streaming;
