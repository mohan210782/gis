import React from 'react';


const Video = React.lazy(() => import('./views/Video'));
const Videomerge = React.lazy(() => import('./views/Videomerge'));


// https://github.com/ReactTraining/react-router/tree/master/packages/react-router-config
const routes = [
  { path: '/', exact: true, name: 'Home' },
  { path: '/video', name: 'Video', component: Video },
  { path: '/videomerge', name: 'Video', component: Videomerge },
  
];

export default routes;
